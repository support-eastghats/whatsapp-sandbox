const AWS = require("aws-sdk");
const connect = new AWS.Connect();

exports.handler = async (event) => {
  try {
    const instanceId = process.env.CONNECT_INSTANCE_ID;
    const { userId } = JSON.parse(event.body);

    // 1. Get user details
    const { User } = await connect.describeUser({
      InstanceId: instanceId,
      UserId: userId
    }).promise();

    const hierarchyGroupId = User.HierarchyGroupId;
    const userGroups = [];

    // 2. Walk hierarchy from bottom to top
    let currentGroupId = hierarchyGroupId;

    while (currentGroupId) {
      const group = await connect.describeUserHierarchyGroup({
        InstanceId: instanceId,
        HierarchyGroupId: currentGroupId
      }).promise();

      userGroups.push(group.HierarchyGroup.Name);
      currentGroupId = group.HierarchyGroup.ParentGroupId;
    }

    // 3. List all routing profiles
    const profiles = await connect.listRoutingProfiles({
      InstanceId: instanceId
    }).promise();

    const matchedProfiles = [];

    for (const profile of profiles.RoutingProfileSummaryList) {
      const tags = await connect.listTagsForResource({
        ResourceArn: profile.Arn
      }).promise();

      const groupTag = tags.Tags?.Group;
      if (groupTag && userGroups.includes(groupTag)) {
        matchedProfiles.push(profile);
      }
    }

    // 4. Get current profile
    const currentProfile = await connect.describeRoutingProfile({
      InstanceId: instanceId,
      RoutingProfileId: User.RoutingProfileId
    }).promise();

    return {
      statusCode: 200,
      body: JSON.stringify({
        currentProfile: currentProfile.RoutingProfile,
        matchedProfiles
      })
    };

  } catch (err) {
    console.error("Error in getMatchingProfiles:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to fetch routing profiles" })
    };
  }
};
