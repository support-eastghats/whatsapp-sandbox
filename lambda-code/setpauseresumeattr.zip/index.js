import { ConnectClient, UpdateContactAttributesCommand } from "@aws-sdk/client-connect";

const connectClient = new ConnectClient({ region: "eu-west-2" });

export const handler = async (event) => {
  console.log("setpauseresumeattr event:", JSON.stringify(event));

  const response = {
    statusCode: 200,
    headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
    body: ''
  };

  try {
    const body = JSON.parse(event.body || '{}');
    const { pauseCtrData, resumeCtrData, contactId, instanceId } = JSON.parse(body.body || '{}');

    const command = new UpdateContactAttributesCommand({
      InitialContactId: contactId,
      InstanceId: instanceId,
      Attributes: {
        'PAUSE-MISDATA': pauseCtrData,
        'RESUME-MISDATA': resumeCtrData
      }
    });

    await connectClient.send(command);
    response.body = JSON.stringify({ message: 'Attributes updated successfully' });

  } catch (err) {
    console.error("setpauseresumeattr error:", err);
    response.statusCode = 500;
    response.body = JSON.stringify({ error: 'Failed to update attributes' });
  }

  return response;
};
