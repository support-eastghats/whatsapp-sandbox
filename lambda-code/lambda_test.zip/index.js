import { S3 } from "@aws-sdk/client-s3";
import bcrypt from "bcryptjs";
import { decryptBody, encryptResponse } from "./aes.js";

const s3 = new S3({ region: "ap-south-1" });
const BUCKET_NAME = "weconnect-scheduling-data-test";

export const handler = async (event) => {
  console.info("📥 [START] Add User Lambda Invoked");

  try {
    if (!event?.body) {
      return generateResponse(400, { error: "Missing request body" });
    }

    let decrypted;
    try {
      decrypted = decryptBody(event.body);
      console.info("🔓 Decrypted Payload:", decrypted);
    } catch (err) {
      console.error("❌ Decryption Failed:", err);
      return generateResponse(400, { error: "Invalid encrypted payload" });
    }

    const { userId, userData } = decrypted;
    const { firstName, lastName, password, confirmPassword, ...otherData } = userData;

    if (!firstName || !lastName) {
      return generateResponse(400, { error: "Missing 'firstName' or 'lastName' field." });
    }

    if (!password) {
      return generateResponse(400, { error: "Password is required." });
    }

    if (password !== confirmPassword) {
      return generateResponse(400, { error: "Passwords do not match." });
    }

    const hashedPassword = await bcrypt.hash(password.trim(), 10);

    const fileKey = `user-info/${firstName}.${lastName}.json`.replace(/\s+/g, ".");

    const userPayload = {
      firstName,
      lastName,
      password: hashedPassword,
      ...otherData,
    };

    await s3.putObject({
      Bucket: BUCKET_NAME,
      Key: fileKey,
      Body: JSON.stringify(userPayload),
      ContentType: "application/json",
      ContentEncoding: "utf-8",
    });

    console.info("✅ User saved to S3:", fileKey);
    return generateResponse(200, {
      message: "User data saved successfully!",
      fileName: fileKey,
    });
  } catch (error) {
    console.error("❌ Error saving user:", error);
    return generateResponse(500, {
      error: "Internal Server Error",
      details: error.message,
    });
  }
};

const generateResponse = (statusCode, body) => ({
  statusCode,
  headers: {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE",
    "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Requested-With",
    "Content-Type": "application/json",
  },
  body: encryptResponse(body),
});
