// index.js
import {
    ConnectClient,
    DescribeUserCommand,
    DescribeUserHierarchyGroupCommand,
    ListRoutingProfilesCommand,
    ListTagsForResourceCommand,
  } from "@aws-sdk/client-connect";
  
  const connect = new ConnectClient({ region: "eu-west-2" });
  
  export const handler = async (event) => {
    console.log("📥 Event:", JSON.stringify(event, null, 2));
    const { userId, instanceId } = JSON.parse(event.body);
  
    const userRes = await connect.send(
      new DescribeUserCommand({ InstanceId: instanceId, UserId: userId })
    );
  
    const currentProfile = userRes.User.RoutingProfileId;
    const hierarchyGroupId = userRes.User.HierarchyGroupId;
  
    const hierarchyRes = await connect.send(
      new DescribeUserHierarchyGroupCommand({
        InstanceId: instanceId,
        HierarchyGroupId: hierarchyGroupId,
      })
    );
  
    const h = hierarchyRes.HierarchyGroup?.HierarchyPath || {};
    const parsed = {
      LevelOne: h.LevelOne?.Name,
      LevelTwo: h.LevelTwo?.Name,
      LevelThree: h.LevelThree?.Name,
    };
  
    const routingRes = await connect.send(
      new ListRoutingProfilesCommand({ InstanceId: instanceId })
    );
  
    const allowedProfiles = [];
    for (const rp of routingRes.RoutingProfileSummaryList || []) {
      const tagRes = await connect.send(
        new ListTagsForResourceCommand({ ResourceArn: rp.Arn })
      );
      const tags = tagRes.Tags || {};
  
      const match =
        (parsed.LevelThree &&
          tags.Project === parsed.LevelOne &&
          tags.Group === parsed.LevelTwo &&
          tags.Role === parsed.LevelThree) ||
        (parsed.LevelTwo &&
          !parsed.LevelThree &&
          tags.Project === parsed.LevelOne &&
          tags.Group === parsed.LevelTwo) ||
        (parsed.LevelOne && !parsed.LevelTwo && tags.Project === parsed.LevelOne);
  
      if (match) {
        allowedProfiles.push({ id: rp.Id, name: rp.Name });
      }
    }
  
    return {
      statusCode: 200,
      body: JSON.stringify({ currentProfile, allowedProfiles }),
    };
  };
  