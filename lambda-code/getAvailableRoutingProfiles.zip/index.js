// Lambda: getAvailableRoutingProfiles with detailed logging
import {
  ConnectClient,
  DescribeUserCommand,
  DescribeUserHierarchyGroupCommand,
  ListRoutingProfilesCommand,
  DescribeRoutingProfileCommand,
  ListTagsForResourceCommand,
} from "@aws-sdk/client-connect";

const connect = new ConnectClient({ region: "eu-west-2" });

export const handler = async (event) => {
  const response = {
    statusCode: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type,x-api-key",
      "Access-Control-Allow-Methods": "POST,OPTIONS",
    },
    body: "",
  };

  try {
    console.info("📥 Incoming event:", JSON.stringify(event));
    const { userId, instanceId } = JSON.parse(event.body);
    console.info("🧾 Parsed Payload:", { userId, instanceId });

    // Step 1: Describe User
    const userRes = await connect.send(
      new DescribeUserCommand({ InstanceId: instanceId, UserId: userId })
    );
    const currentProfile = userRes.User?.RoutingProfileId;
    const hierarchyGroupId = userRes.User?.HierarchyGroupId;
    const userArn = userRes.User?.Arn;
    const usertags = userRes.User?.Tags || {};
    console.info("👤 DescribeUser:", {
      currentProfile,
      hierarchyGroupId,
      userArn,
      usertags,
    });

    // Step 2: Describe Hierarchy Group
    const hierarchyRes = await connect.send(
      new DescribeUserHierarchyGroupCommand({
        InstanceId: instanceId,
        HierarchyGroupId: hierarchyGroupId,
      })
    );

    const hierarchy = hierarchyRes.HierarchyGroup?.HierarchyPath || {};
    const parsedHierarchy = {
      LevelOne: hierarchy.LevelOne?.Name,
      LevelTwo: hierarchy.LevelTwo?.Name,
      LevelThree: hierarchy.LevelThree?.Name,
    };
    console.info("📊 Parsed Hierarchy:", parsedHierarchy);

    // Step 3: List all Routing Profiles
    const profilesRes = await connect.send(
      new ListRoutingProfilesCommand({ InstanceId: instanceId })
    );
    console.info(
      "📦 Total Routing Profiles:",
      profilesRes.RoutingProfileSummaryList?.length
    );

    const allowedProfiles = [];

    for (const profile of profilesRes.RoutingProfileSummaryList || []) {
      try {
        // Step 4: Describe each routing profile to get its tags
        const fullProfile = await connect.send(
          new DescribeRoutingProfileCommand({
            InstanceId: instanceId,
            RoutingProfileId: profile.Id,
          })
        );

        const tags = fullProfile.RoutingProfile?.Tags || {};
        console.info(`🏷️ Tags for profile ${profile.Name} [${profile.Id}]:`, tags);

        // Step 5: Match hierarchy tags - STRICT BASED ON DEPTH
        let match = false;

        const hasLevelOne = !!parsedHierarchy.LevelOne;
        const hasLevelTwo = !!parsedHierarchy.LevelTwo;
        const hasLevelThree = !!parsedHierarchy.LevelThree;

        if (hasLevelOne && !hasLevelTwo && !hasLevelThree) {
          match = tags.Project === parsedHierarchy.LevelOne;
        } else if (hasLevelOne && hasLevelTwo && !hasLevelThree) {
          match =
            tags.Project === parsedHierarchy.LevelOne &&
            tags.Group === parsedHierarchy.LevelTwo;
        } else if (hasLevelOne && hasLevelTwo && hasLevelThree) {
          match =
            tags.Project === parsedHierarchy.LevelOne &&
            tags.Group === parsedHierarchy.LevelTwo &&
            tags.Role === parsedHierarchy.LevelThree;
        }

        if (match) {
          allowedProfiles.push({ id: profile.Id, name: profile.Name, reason: "hierarchy" });
        }
      } catch (err) {
        console.error(
          `❌ Failed to get tags for profile: ${profile.Arn} [${profile.Id}]`,
          err
        );
      }
    }

    // Step 6: Match if user's RouteProfile tag matches routing profile name
    try {
      const userTagValue = usertags?.RouteProfile;
      console.info("🔎 Checking user RouteProfile tag against profile names:", userTagValue);

      for (const profile of profilesRes.RoutingProfileSummaryList || []) {
        const alreadyIncluded = allowedProfiles.some(p => p.id === profile.Id);

        if (userTagValue === profile.Name && !alreadyIncluded) {
          allowedProfiles.push({ id: profile.Id, name: profile.Name, reason: "user-tag" });
          console.info(`🟢 Matched RouteProfile tag from user: ${profile.Name}`);
        } else {
          console.info(`⚪ Skipped user-tag match: ${profile.Name} → matched: ${userTagValue === profile.Name}, alreadyIncluded: ${alreadyIncluded}`);
        }
      }
    } catch (err) {
      console.error("❌ Failed to match user tag RouteProfile:", err);
    }


    // Step 7: Final response
    response.body = JSON.stringify({ currentProfile, allowedProfiles });
    console.info("✅ Response ready:", response.body);
  } catch (err) {
    console.error("🔥 Unexpected error:", err);
    response.statusCode = 500;
    response.body = JSON.stringify({ error: "Internal server error" });
  }

  return response;
};
